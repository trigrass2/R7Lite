#ifndef DEBUG
#define DEBUG  1
#endif

#define _FILE_OFFSET_BITS 64

#include "lib/pciDriver.h"
#include "driver/pciDriver.h"

#include <termios.h> 
#include <sys/ioctl.h> 
#include <sys/time.h> 
#include <sys/types.h>
#include "string.h"
#include "stdlib.h"
#include <stdio.h>
#include <sys/timeb.h>
#include "unistd.h"
#include <pthread.h>
#include <stdarg.h>     // For va_start() & va_end()

#include <linux/kernel.h>


#ifndef CHAR
#define CHAR unsigned char
#endif

#ifndef DWORD
#define DWORD unsigned int
#define PDWORD unsigned int *
#endif

#ifndef INFINITE
#define INFINITE 0xFFFFFFFF
#endif
/************************************
macro defs
*************************************/
#define CH0_CNTRL_REG           0xB0
#define CH0_STATUE_REG          0xB0
#define CH0_DRATE_H32           0xB4
#define CH0_DRATE_L32           0xB8
#define CH0_PNI_NUM_H32         0xBC
#define CH0_PNI_NUM_L32         0xC0
#define CH0_PNQ_NUM_H32         0xC4
#define CH0_PNQ_NUM_L32         0xC8
#define CH0_REC_NUM_H32         0xCC
#define CH0_REC_NUM_L32         0xD0
#define CH0_DDR3_USED			0xD

#define CH1_CNTRL_REG           0xE0
#define CH1_STATUE_REG          0xE0
#define CH1_DRATE_H32           0xE4
#define CH1_DRATE_L32           0xE8
#define CH1_PNI_NUM_H32         0xEC
#define CH1_PNI_NUM_L32         0xF0
#define CH1_PNQ_NUM_H32         0xF4
#define CH1_PNQ_NUM_L32         0xF8
#define CH1_REC_NUM_H32         0xFC
#define CH1_REC_NUM_L32         0x100
#define CH1_DDR3_USED			0x104

#define CH0_DMA_SIZE			0x108
#define CH1_DMA_SIZE			0x10C

//#define INT_VECTOR              0x50

#define DDR3_INIT_COMPLETED		(1 << 30)	// DDR3 initial completed after eb fifo reset

/* IRQ_SOURCES */
#define XDK7_IRQ_US 	        0
#define XDK7_IRQ_DS 	        1
#define XDK7_IRQ_IG 	        2
#define XDK7_IRQ_CH0 	        3
#define XDK7_IRQ_CH1 	        4
#define XDK7_IRQ_DAQ 	        5

/* See XDK7 user’s guide, register definitions (3.2) */
#define XDK7_INT_ENABLE 		(0x0010 >> 2)
#define XDK7_INT_STAT 	        (0x0008 >> 2)

#define XDK7_INT_US_TIMEOUT     (1 << 4)
#define XDK7_INT_DS_TIMEOUT     (1 << 5)
#define XDK7_INT_IG  	        (1 << 2)
#define XDK7_INT_DS 	        (1 << 1) /* downstream */
#define XDK7_INT_US 	        (1)      /* upstream */

#define XDK7_POLL_US_TIMEOUT    (1 << 20)
#define XDK7_POLL_DS_TIMEOUT    (1 << 21)
#define XDK7_POLL_IG  	        (1 << 18)
#define XDK7_POLL_DS 	        (1 << 17) /* downstream */
#define XDK7_POLL_US 	        (1 << 16) /* upstream */

#define XDK7_INT_CH0 	        (1 << 22) /* DAQ Ch0 */
#define XDK7_INT_CH1 	        (1 << 23) /* DAQ Ch1 */
#define XDK7_INT_DAQ 	        (1 << 24) /* DAQ two channel */
#define XDK7_INT_CH0_TIMEOUT 	(1 << 26) /* DAQ Ch0 TO*/
#define XDK7_INT_CH1_TIMEOUT 	(1 << 27) /* DAQ Ch1 TO*/
#define XDK7_INT_DAQ_TIMEOUT 	(1 << 28) /* DAQ two channel TO*/

#define XDK7_DS_CTRL  	        (0x006C >> 2)
#define XDK7_US_CTRL  	        (0x0048 >> 2)
#define XDK7_DMA_RESET 	        (0x0200000A)
#define XDK7_IG_CTRL 	        (0x0080 >> 2)
#define XDK7_IG_LAT 	        (0x0084 >> 2)
#define XDK7_IG_ACK 	        (0x00F0)

#define XDK7_CH0_CTRL  	        (0x00B0 >> 2)
#define XDK7_CH1_CTRL  	        (0x00E0 >> 2)
#define XDK7_CH0_CTRL_CLEAR		(0x30000)
#define XDK7_RESET				(0x0000000A)

#define XDK7_MRd_CTRL  	        (0x0074 >> 2)
#define XDK7_CplD_CTRL  	    (0x0078 >> 2)
#define XDK7_FIFO_CTRL  	    (0x0090 >> 2)

#define XDK7_CH0_DMASIZE  	    (0x0108 >> 2)
#define XDK7_CH1_DMASIZE  	    (0x010C >> 2)

#define DMA_TIMEOUT_SEC         3                                       // Max time to wait for DMA completion
#define UPDATE_DISPLAY_SEC      4                                       // Number of seconds between display updates

#define MAX_DMA_LENGTH			0x400000	//4MB
#define CH0_DMA_LOCAL_ADDR		0x10000000	//highest addr bit is 1, allows <2GB transaction
#define CH1_DMA_LOCAL_ADDR		0x20000000

#define buf_len  				512*1024	//16KB
#define LoopBufferSize 			4*1024*1024
#define LoopBufferBlockCount	8
#define WriteSize				4*1024*1024
#define ReadSize				4*1024*1024

#define DMATimes 	(LoopBufferSize/(buf_len))
#define WriteTimes	(LoopBufferSize/(WriteSize))
#define ReadTimes	(LoopBufferSize/(ReadSize))

#define MAX 71

#define DIAG_EXIT_MENU 99

#define FileLength 1024

#define MAX_UBUF 64*1024*1024

/************************************
variable defs
*************************************/

typedef enum {
        UNOPENED,
        OPENED,
        INITED,
        STARTUP
}DEVICE_STATE;

typedef struct {
	unsigned int src_addr_h;
	unsigned int src_addr_l;
	unsigned int dst_addr_h;
	unsigned int dst_addr_l;
	unsigned int next_bda_h;
	unsigned int next_bda_l;		
	unsigned int length;		
	unsigned int control;			
	unsigned int status;
} bda_t;

typedef enum {
				false =0,
				true
			}bool;
			
typedef enum {
				DIAG_INPUT_CANCEL = -1,
				DIAG_INPUT_FAIL = 0,
				DIAG_INPUT_SUCCESS = 1
			} DIAG_INPUT_RESULT;

/************************************
function defs
*************************************/
void testPCIconfig(pd_device_t *dev);
void testXDReset(pd_device_t *dev);
void NonDMARead(pd_device_t *dev);
void NonDMAWrite(pd_device_t *dev);
void KDMARead(pd_device_t *dev);
void UDMARead(pd_device_t *dev);
void* thread1();
void* thread2();
int Cons_kbhit(void);
int Cons_getch(void);
void write_dma(unsigned int *bar0, bda_t dma);
void main_menu();
DIAG_INPUT_RESULT GetMenuOption(PDWORD pdwOption, DWORD dwMax);
void ExamFile();

// void *int_handler(pd_device_t *dev);

// /* Global used by the interrupt thread */
// pthread_mutex_t int_mutex;
// bool thread_alive;
// unsigned long int_count;

unsigned long *ptr0,*ptr1;	

pd_device_t dev;
pci_board_info dev_info;
unsigned int irq;
unsigned short vendor_id;
unsigned short device_id;
unsigned char interrupt_pin;
unsigned char interrupt_line;
bool		CH0_FLAG,CH1_FLAG;
bool		CH0_PAUSE,CH1_PAUSE;
DEVICE_STATE		DeviceState = UNOPENED;


//ch0 loopbuffer
long long m_llRAIDTotalReadPointer1,m_llRAIDTotalReadPointer2;
long	 m_lRAIDReadPointer1,m_lRAIDReadPointer2;
int      m_iRAIDTotalReadBlockID1,m_iRAIDTotalReadBlockID2;
int      m_iRAIDReadBlockID1,m_iRAIDReadBlockID2;	

long long m_llRAIDTotalWritePointer1,m_llRAIDTotalWritePointer2;
long	 m_lRAIDWritePointer1,m_lRAIDWritePointer2;
int      m_iRAIDTotalWriteBlockID1,m_iRAIDTotalWriteBlockID2;
int      m_iRAIDWriteBlockID1,m_iRAIDWriteBlockID2;

long long m_llTotalWritePointer1,m_llTotalWritePointer2;
long	 m_lWritePointer1,m_lWritePointer2;
int		 m_iTotalWriteBlockID1,m_iTotalWriteBlockID2;
int		 m_iWriteBlockID1,m_iWriteBlockID2;

long long m_llTotalReadPointer1,m_llTotalReadPointer2;
long	 m_lReadPointer1,m_lReadPointer2;
int		 m_iTotalReadBlockID1,m_iTotalReadBlockID2;
int		 m_iReadBlockID1,m_iReadBlockID2;

void 	LoopBufferInit1();
void 	LoopBufferDel1();
void	LB_ResetLoopBuffer1();
void	LB_PositionReadPointer1();
unsigned char		LB_LoopBufferDataWrite1();

void 	LoopBufferInit2();
void 	LoopBufferDel2();
void	LB_ResetLoopBuffer2();
void	LB_PositionReadPointer2();
unsigned char		LB_LoopBufferDataWrite2();

unsigned char*		m_pRawDataBuffer1;
unsigned char*		m_pRawDataBuffer2;
int		m_iTotalSize1,m_iTotalSize2;
int		m_iBlockSize1,m_iBlockSize2;
int		m_iBlockCount1,m_iBlockCount2;


FILE              *fp0,*fp1;

pthread_t thread[2];
bool m_bRAIDThread1;
bool m_bRAIDThread2;
int  m_iTotalCount1,m_iCount1;
int  m_iTotalCount2,m_iCount2;
int  blockcount1;
int  blockcount2;
int  m_iCounter1;
int  m_iCounter2;
int  iRet1;
int  iRet2;

