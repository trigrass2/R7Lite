
#include "pcie_test.h"

/***************************************************************
main function
***************************************************************/
int main(int argc, char* argv[]){
	main_menu();

	if(DeviceState>= OPENED){
		if(pd_close(&dev)<0){
			printf("-->Close device failed!!\r\n");
		}				
	}
	return 0;
}

/***************************************************************
Get menu option from user
***************************************************************/

DIAG_INPUT_RESULT GetMenuOption(PDWORD pdwOption, DWORD dwMax)
{
	//static char sInput[256];
	int iRet;

	if (!pdwOption)	{
		printf("-->Error: No Option\n");
		return DIAG_INPUT_FAIL;
	}

	printf("-->Input Menu Option: ");

	//fgets(sInput, sizeof(sInput), stdin);

    //iRet = sscanf(sInput, "%ld", pdwOption);
    iRet = scanf("%d", pdwOption);

    getchar();
        	
	if (iRet < 1)
	{
		printf("-->Invalid Option\n");
		return DIAG_INPUT_FAIL;
	}

	if (DIAG_EXIT_MENU == *pdwOption)
		return DIAG_INPUT_SUCCESS;

	if (!dwMax)
		return DIAG_INPUT_SUCCESS;

	if (*pdwOption > dwMax)
	{
		printf("-->Invalid Option: Option Should be %s%d, or input %d to exit.\n",
			(1 == dwMax) ? "" : "between 1 - ",
			dwMax, 
			DIAG_EXIT_MENU
			);

		return DIAG_INPUT_FAIL;
	}

	return DIAG_INPUT_SUCCESS;
}


/***************************************************************
main menu
***************************************************************/
	enum {
		MENU_MAIN_Open_Dev = 1,
		MENU_MAIN_Close_Dev,
		MENU_MAIN_Reset_Dev,
		MENU_MAIN_ConfigSpace,  
		MENU_MAIN_NonDMARead,  
		MENU_MAIN_NonDMAWrite,
		MENU_MAIN_KDMARead,
		MENU_MAIN_UDMARead,
		MENU_MAIN_EXAMFILE,
		MENU_MAIN_EXIT = DIAG_EXIT_MENU,
	};

void main_menu(){
	unsigned int option;
	int ret;
	
	printf("\nMain Menu\r\n");
	do{
		printf("-------------------------------------\r\n");
		if(DeviceState!=UNOPENED){

			printf("%d.  Close XD_V1 Device\r\n", MENU_MAIN_Close_Dev);
			printf("%d.  Reset XD_V1 Device\n", MENU_MAIN_Reset_Dev);	
			
			printf("%d.  ConfigSpace Read from XD_V1\r\n", MENU_MAIN_ConfigSpace);
			
			printf("%d.  NonDMA Read from XD_V1\r\n", MENU_MAIN_NonDMARead);
			printf("%d.  NonDMA Write to XD_V1 \r\n", MENU_MAIN_NonDMAWrite);
			
			printf("%d.  DMA Read from XD_V1 with kernel memory\r\n", MENU_MAIN_KDMARead);
			printf("%d.  DMA Read from XD_V1 with user memory\r\n", MENU_MAIN_UDMARead);
			
			printf("%d.  Counter Data Examine\r\n", MENU_MAIN_EXAMFILE);

			printf("%d.  Exit\r\n",MENU_MAIN_EXIT);
		}else{
			printf("%d.   Find and Open XD_V1 Device\r\n", MENU_MAIN_Open_Dev);
            printf("%d.  Exit\r\n",MENU_MAIN_EXIT);
		}

                printf("-------------------------------------\r\n");
		
		if (DIAG_INPUT_FAIL == GetMenuOption(&option,  MENU_MAIN_EXAMFILE))
		{
			continue;
		}

		switch(option){
//---------------------------------------------------------------------------------------------
			case MENU_MAIN_Open_Dev:
				if(DeviceState!= UNOPENED){
					printf("-->Device already opend!\r\n");
                    continue;
				}

				//open device
				ret = pd_open(0,&dev);
				if(ret != 0){
					printf("return code is %d\n",ret);
					printf("-->Failed to open device!\r\n");
					continue;
				}	
				
				ret = ioctl(dev.handle,PCIDRIVER_IOC_PCI_INFO, &dev_info);
				irq = dev_info.irq;
				vendor_id = dev_info.vendor_id;
				device_id = dev_info.device_id;
				interrupt_pin = dev_info.interrupt_pin;
				interrupt_line = dev_info.interrupt_line;
				printf("device irq = %d\n",irq);
				printf("device vendor_id = %x\n",vendor_id);
				printf("device device_id = %x\n",device_id);
				printf("device interrupt_pin = %d\n",interrupt_pin);
				printf("device interrupt_line = %d\n",interrupt_line);

				DeviceState = OPENED;
				break;
//---------------------------------------------------------------------------------------------
			case MENU_MAIN_Close_Dev:
                if(DeviceState==UNOPENED){
					printf("-->Device hasn't been opened yet\r\n");
					continue;
				}
				
				if(pd_close(&dev)!=0){
					printf("-->Close device failed!\r\n");
					continue;
				}				
				DeviceState=UNOPENED;
				break;
//---------------------------------------------------------------------------------------------
			case MENU_MAIN_Reset_Dev: /* Soft board reset */	
				if(DeviceState==UNOPENED){
					printf("-->Device hasn't been opened yet\r\n");
					continue;
				}
				testXDReset(&dev);
				break;
//---------------------------------------------------------------------------------------------
			case MENU_MAIN_ConfigSpace:
				if(DeviceState==UNOPENED){
					printf("-->Device hasn't been opened yet\r\n");
					continue;
				}
				testPCIconfig(&dev);
				break;
//---------------------------------------------------------------------------------------------
			case MENU_MAIN_NonDMARead:
				if(DeviceState==UNOPENED){
					printf("-->Device hasn't been opened yet\r\n");
					continue;
				}
				NonDMARead(&dev);
				break;
//---------------------------------------------------------------------------------------------
			case MENU_MAIN_NonDMAWrite:
				if(DeviceState==UNOPENED){
                   printf("-->Device hasn't been opened yet\r\n");
					continue;
				}
				NonDMAWrite(&dev);
				break;
//---------------------------------------------------------------------------------------------
			case MENU_MAIN_KDMARead:
				if(DeviceState==UNOPENED){
					printf("-->Device hasn't been opened yet\r\n");
					continue;
				}
				KDMARead(&dev);
				break;
//---------------------------------------------------------------------------------------------
			case MENU_MAIN_UDMARead:
				if(DeviceState==UNOPENED){
					printf("-->Device hasn't been opened yet\r\n");
					continue;
				}
				UDMARead(&dev);
				break;				
//---------------------------------------------------------------------------------------------
			case MENU_MAIN_EXAMFILE:
				ExamFile();
				break;
//---------------------------------------------------------------------------------------------
			case MENU_MAIN_EXIT:
				break;
//---------------------------------------------------------------------------------------------
			default:
				continue;
		}
	}while(MENU_MAIN_EXIT != option);
	
}


/********************************************************************


 *********************************************************************/
void testPCIconfig(pd_device_t *dev)
{
	int i,j,ret;
	
	printf("-->Testing PCI config ... \n");
	// printf("  Reading PCI config area in byte mode ... \n");
	// for(i=0;i<32;i++) {
		// printf("   %03d: ", i*8 );
		// for(j=0;j<8;j++) {
			// ret = pd_readConfigByte( dev, (i*8)+j );
			// printf("%02x ",ret);
		// }
		// printf("\n");
	// }

	// printf("  Reading PCI config area in word mode ... \n");
	// for(i=0;i<32;i++) {
		// printf("   %03d: ", i*8 );
		// for(j=0;j<8;j+=2) {
			// ret = pd_readConfigWord( dev, (i*8)+j );
			// printf("%04x ",ret);
		// }
		// printf("\n");
	// }

	printf("-->Reading PCI config area in double-word mode ... \n");
	for(i=0;i<32;i++) {
		printf("   %03d: ", i*8 );
		for(j=0;j<8;j+=4) {
			ret = pd_readConfigDWord( dev, (i*8)+j );
			printf("%08x ",ret);
		}
		printf("\n");
	}
	
	//pd_writeConfigWord( dev, 0x4 ,);

}
/********************************************************************


 *********************************************************************/

void testXDReset(pd_device_t *dev)
{
	int i,j,ret;
	unsigned int val[MAX];
	unsigned int *bar;
	int bar2ctrl = 0;

	printf("-->Doing Soft Reset... \n");
	printf("-->Mapping BAR %d ...",bar2ctrl);
	bar = pd_mapBAR( dev, bar2ctrl );
	if (bar == NULL) {
		printf("failed\n");
		return;
	}
	else{
		printf("mapped\n");	
	}		

	bar[XDK7_INT_ENABLE] = 0x0;//bar+0x0010
	printf("-->Clear Interrupt Enable Register.\tbar[4]=%08x\n",bar[XDK7_INT_ENABLE]);
	
	bar[XDK7_MRd_CTRL] = XDK7_RESET;//bar+0x0074
	sleep(0);
	printf("-->Reset MRd Channel Control Register.\tbar[29]=%08x\n",bar[XDK7_MRd_CTRL]);
	
	bar[XDK7_CplD_CTRL] = XDK7_RESET;//bar+0x0078
	sleep(0);
	printf("-->Reset CplD Channel Control Register.\tbar[30]=%08x\n",bar[XDK7_CplD_CTRL]);
	
	bar[XDK7_FIFO_CTRL] = XDK7_RESET;//bar+0x0090
	sleep(0);
	printf("-->Reset FIFO Control Register.\tbar[36]=%08x\n",bar[XDK7_FIFO_CTRL]);
	
	bar[XDK7_US_CTRL] = XDK7_DMA_RESET;//bar+0x0048	
	sleep(0);
	printf("-->Reset DMA upstream(Board-Host) Control Register.\tbar[18]=%08x\n",bar[XDK7_US_CTRL]);
	
	bar[XDK7_DS_CTRL] = XDK7_DMA_RESET;//bar+0x006C
	sleep(0);
	printf("-->Reset DMA downstream(Host-Board) Control Register.\tbar[27]=%08x\n",bar[XDK7_DS_CTRL]);
	
	bar[XDK7_CH0_CTRL] = 0x00010000;//bar+0x00B0	
	sleep(0);
	printf("-->Clear Ch0 pn_error Register.\tbar[48]=%08x\n",bar[48]);
	
	bar[XDK7_CH0_CTRL] = 0x00020000;//bar+0x00B0
	sleep(0);
	printf("-->Clear Ch0 total_size Register.\tbar[50]=%08x\n",bar[50]);
	
	bar[XDK7_CH1_CTRL] = 0x00010000;//bar+0x00E0
	sleep(0);
	printf("-->Clear Ch1 pn_error Register.\tbar[60]=%08x\n",bar[60]);
	
	bar[XDK7_CH1_CTRL] = 0x00020000;//bar+0x00E0
	sleep(0);
	printf("-->Clear Ch1 total_size Register.\tbar[62]=%08x\n",bar[62]);
	

	bar[32] = XDK7_RESET;

	printf("-->UnMapping BAR %d ...",bar2ctrl);
	ret=pd_unmapBAR( dev,bar2ctrl,bar );
	if (ret < 0) {
		printf("failed\n");
		return;
	}
	printf("unmapped\n");	

}
/********************************************************************


 *********************************************************************/
void NonDMARead(pd_device_t *dev) {
	int j,ret;
	unsigned int val[MAX];
	unsigned int *bar;
	int bar2ctrl = 0;

	printf("-->Testing Non DMA Reading... \n");
	printf("-->Mapping BAR %d ...",bar2ctrl);
	bar = pd_mapBAR( dev, bar2ctrl );
	if (bar == NULL) {
		printf("failed\n");
		return;
	}
	else{
		printf("mapped\n");	
	}		
	
	//bar[XDK7_CH0_CTRL] = 0x00010095;
	//bar[XDK7_CH1_CTRL] = 0x00010095;
	
	
	for(j=44;j<67;j++){
		val[j] = bar[j];
	}
	val[2] = bar[2];
	printf("-->ISR :   			%x\n",val[2]);
	printf("\n");	
	printf("-->Channle0 Control Statue  Register:   %x\n",val[44]);	
	printf("-->Channle0 Data Rate L :   	%d\n",val[46]);
	printf("-->Channle0 I PN error count:  %d\n",512*val[47]+val[48]);
	printf("-->Channle0 record size:   	%d MB\n",512*val[51]+val[52]/1024/1024/8);
	printf("-->Channle0 ddr3 memory used:   %6.3f MB\n",(double)val[53]/1024/1024);
	printf("-->Channle0 dma size: %d\n",val[66]);
	printf("\n");
	printf("-->Channle1 Control Statue  Register:   %x\n",val[56]);	
	printf("-->Channle1 Data Rate L :       %d\n",val[58]);
	printf("-->Channle1 I PN error count:  %d\n",512*val[59]+val[60]);
	printf("-->Channle1 record size:       %d MB\n",512*val[63]+val[64]/1024/1024/8);
	printf("-->Channle1 ddr3 memory used:   %6.3f MB\n",(double)val[65]/1024/1024);
	printf("-->Channle1 dma size: %d\n",val[67]);
	printf("\n");
	printf("\n");

	printf("UnMapping BAR %d ...",bar2ctrl);
	ret=pd_unmapBAR( dev,bar2ctrl,bar );
	if (ret < 0) {
		printf("failed\n");
		return;
	}
	printf("unmapped\n");		
}

/********************************************************************


 *********************************************************************/
void NonDMAWrite(pd_device_t *dev) {
	int ret;
	unsigned int addr;
	unsigned int val;	
	unsigned int *bar;
	int bar2ctrl = 0;
	
	printf("-->Testing Non DMA Writing... \n");
	printf("-->Mapping BAR %d ...",bar2ctrl);
	bar = pd_mapBAR( dev, bar2ctrl );
	if (bar == NULL) {
		printf("failed\n");
		return;
	}
	else{
		printf("mapped\n");	
	}	
	
	do {
		printf("-->Input address(32bit) to write in hex format-->0x");
		scanf("%x", &addr);
		getchar();
	} while (addr > MAX*4);	
	
	printf("-->Input data(32bit) to write in hex format:\n-->0x");
	scanf("%x", &val);
	getchar();
	
	
	*(bar+(addr>>2)) = val;
	
	
	printf("-->Data write to bar %d @ offset [0x%x] is: 0x%x\r\n", bar2ctrl, addr, val);
	printf("-->Readback Data is: 0x%x\r\n", *(bar+(addr>>2)));	
	
		
	printf("UnMapping BAR %d ...",bar2ctrl);
	ret=pd_unmapBAR( dev,bar2ctrl,bar );
	if (ret < 0) {
		printf("failed\n");
		return;
	}
	printf("unmapped\n");	
}


/********************************************************************


 *********************************************************************/
void KDMARead(pd_device_t *dev) {
	int i,j,ret;
	unsigned int 		val[MAX];
	unsigned int 		*bar0;
	//unsigned int 		*bar1;
	unsigned long 		*bar2;
	
	pd_kmem_t km0,km1;	
	bda_t dma0,dma1;	

	unsigned int		UserInput;
    unsigned int		int_reg;
    unsigned int		LoopCount;
   	unsigned long		PollCount;
    unsigned int		ElapsedTime_ms;
   	double				Stat_TxTotalCount;
    double				Stat_TxTotalBytes;
    struct timeb		StartTime, EndTime;
	struct timeb		LoopStartTime, LoopEndTime;
   	bool           		bInterrupts;
	unsigned int		ControlValue;	
	int					int_count;
	int 				Channel_option;
	int					iRet;

	m_iTotalCount1=0;
	m_iCount1=0;
	m_iTotalCount2=0;
	m_iCount2=0;
	blockcount1 = 0;
	blockcount2 = 0;
	m_bRAIDThread1 = 1;	
	m_bRAIDThread2 = 1;
	LoopCount = 0;
	Stat_TxTotalCount = 0;
	Stat_TxTotalBytes = 0;
	
	
	printf("-->Testing DMA Reading(Upstream) with Kernel Memory... \n");
	
	printf("  Map BAR 0 for register access..\n ");
	bar0 = pd_mapBAR( dev, 0 );
	//bar1 = pd_mapBAR( dev, 1 );
	bar2 = pd_mapBAR( dev, 2 );
	
    // Determine whether to use interrupts or polling
	printf("  Use interrupts(i) or poll(p) [i/p]? --> ");	
	UserInput = getchar();

	if (UserInput == 'i' || UserInput == 'I')
		bInterrupts = 1;
	else
		bInterrupts = 0;

	if(bInterrupts){
		printf("  Use interrupts(i) mode\n");	
		pd_clearInterruptQueue(dev,XDK7_IRQ_US);
		pd_clearInterruptQueue(dev,XDK7_IRQ_IG);
//		pd_clearInterruptQueue(dev,XDK7_IRQ_CH0);
//		pd_clearInterruptQueue(dev,XDK7_IRQ_CH1);
//		pd_clearInterruptQueue(dev,XDK7_IRQ_DAQ);
	}

	printf("  which channel to test? 1:ch1,\t2:ch2,\t3:both --> ");	
	
	iRet = scanf("%d", &Channel_option);
	if(iRet<1){
		printf("-->Invalid Option\n");
		return;
	}
	else{
		//printf("-->Channel_option:%d\n",Channel_option);
	}

    	getchar();		

	if (Channel_option == 1){
		CH0_FLAG = 1;
		CH1_FLAG = 0;
		printf("\tTest ch1\n");
	}
	else if(Channel_option == 2){
		CH0_FLAG = 0;
		CH1_FLAG = 1;
		printf("\tTest ch2\n");
	}
	else if(Channel_option == 3){
		CH0_FLAG = 1;
		CH1_FLAG = 0;
		printf("\tTest both ch\n");
	}else{
		printf("-->Invalid Option\n");
		return;
	}

	CH0_PAUSE = 1;
	CH1_PAUSE = 1;
	
	printf("  ControlRegister Value in hex format:\n-->0x");
	scanf("%x", &ControlValue);
	
	getchar();
	
	printf("  Initial Loop Buffer.........\n ");
	LoopBufferInit1();
	LoopBufferInit2();
	
	//allocKernelMemory
	ptr0 = (unsigned long *)pd_allocKernelMemory( dev, buf_len, &km0 );
	ptr1 = (unsigned long *)pd_allocKernelMemory( dev, buf_len, &km1 );
	if ((ptr0 == NULL) || (ptr1 == NULL)) {
		printf("failed\n");
		pd_unmapBAR( dev,0, bar0 );
		//pd_unmapBAR( dev,1, bar1 );
		pd_unmapBAR( dev,2, bar2 );
		return;
	}

	printf("  Open Files.........\n");
	if((fp0=fopen("/home/radi/rpdll/Data/ch0","wb"))==NULL)	{
		perror(NULL);
		printf("        -->Err: unable to open file ch0! \r\n");
	}
	else
		printf("      ch0 file open ok\n");
	
	
	if((fp1=fopen("/home/radi/rpdll/Data/ch1","wb"))==NULL){
		perror(NULL);
		printf("        -->Err: unable to open file ch1! \r\n");
	}
	else
		printf("      ch1 file open ok\n");

	printf("  Creating WriteFile Threads.........\n");
	memset(&thread, 0, sizeof(thread));          			
	if(pthread_create(&thread[0], NULL, thread1, NULL) != 0)      
			printf("      Create thread1 failed!\n");
	else
			printf("      Create thread1 ok\n");
	if(pthread_create(&thread[1], NULL, thread2, NULL) != 0)  
			printf("      Create thread2 failed");
	else
			printf("      Create thread2 ok\n");

	//Reset the DMA upstream channel
	bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;	

	bar0[XDK7_MRd_CTRL] = XDK7_RESET;
	bar0[XDK7_CplD_CTRL] = XDK7_RESET;
	//Reset fifo		
	bar0[XDK7_FIFO_CTRL] = XDK7_RESET;

	//Reset IGC
	bar0[XDK7_IG_CTRL] = XDK7_RESET;

	bar0[XDK7_CH0_DMASIZE]	= buf_len;
	bar0[XDK7_CH1_DMASIZE]	= buf_len;

	//write the control reg to start
	if (Channel_option == 1){
		bar0[XDK7_CH0_CTRL] = ControlValue;
	}
	else if (Channel_option == 2){
		bar0[XDK7_CH1_CTRL] = ControlValue;
	}
	else if (Channel_option == 3){
		bar0[XDK7_CH0_CTRL] = ControlValue;
		bar0[XDK7_CH1_CTRL] = ControlValue;
	}
	
	//printf(" ch0 CTRL= %x\n",bar0[XDK7_CH0_CTRL]);
	
	ftime( &StartTime );		
	
	printf("-->DMA Read Start...\n");

	do {	
		
		if (bInterrupts){	
			bar0[XDK7_INT_ENABLE] = XDK7_INT_IG | XDK7_INT_CH0 | XDK7_INT_CH1 | XDK7_INT_CH0_TIMEOUT | XDK7_INT_CH1_TIMEOUT | XDK7_INT_DAQ | XDK7_INT_DAQ_TIMEOUT;
		}else{	
			bar0[XDK7_INT_ENABLE] = XDK7_INT_CH0 | XDK7_INT_CH1 | XDK7_INT_CH0_TIMEOUT | XDK7_INT_CH1_TIMEOUT | XDK7_INT_DAQ | XDK7_INT_DAQ_TIMEOUT;
		}
			
		
		bar0[XDK7_IG_LAT] = 0xFA;//0xFA = 250  * 4ns = 1us,

		if (bInterrupts){
			iRet = pd_waitForInterrupt(dev,XDK7_IRQ_IG);
			if(!iRet){
				val[2]	= bar0[XDK7_INT_STAT];				
				//printf(" DAQ Interupts received bar0[XDK7_INT_STAT]= %x\n",val[2]);
				//bar0[XDK7_IG_LAT] = 0x0;
				//bar0[XDK7_INT_ENABLE] = 0x0;	//clear int enable	
				
				if((val[2]  & XDK7_INT_DAQ_TIMEOUT) == XDK7_INT_DAQ_TIMEOUT){
					printf("  Waiting DAQ timeout\n");
					goto _ExitDmaTest;
				}
			}
			else{
				printf("  Waiting INT timeout\n");
				goto _ExitDmaTest;	
			}		
		}	
		else{
				 	 	 	
			do{	
				val[2]	= bar0[XDK7_INT_STAT];
				sleep(0);
				
				if((val[2]  & XDK7_INT_DAQ_TIMEOUT) == XDK7_INT_DAQ_TIMEOUT){
					printf("  Waiting DAQ timeout\n");
					goto _ExitDmaTest;
				}
			}while((val[2] & XDK7_INT_DAQ) != XDK7_INT_DAQ);	
							
		}
	  // Periodically display statistics
		if ((LoopCount & 0x0000003F) == 0){
			// Get end time
			ftime( &EndTime );

			// Calculate elapsed time in milliseconds
			ElapsedTime_ms = (((unsigned int)EndTime.time * 1000) + EndTime.millitm) -
							 (((unsigned int)StartTime.time * 1000) + StartTime.millitm);

			if (ElapsedTime_ms >= (UPDATE_DISPLAY_SEC * 1000)){
				// Display statistics
				if (ElapsedTime_ms != 0){
					printf(
						" Transfers: %0.0lf   Bytes: %0.2lf MB   Time: %ldms   Rate:%6.3lf MB/s\n",
						Stat_TxTotalCount, Stat_TxTotalBytes / (1 << 20), ElapsedTime_ms,
						((Stat_TxTotalBytes * 1000) / (double)ElapsedTime_ms) / (double)(1 << 20)
						);								
					val[46] = bar0[46];//rate
					val[47] = bar0[47];//error h
					val[48] = bar0[48];//error l
					val[58] = bar0[58];//rate
					val[59] = bar0[59];//error h					
					val[60] = bar0[60];//error l
					val[51] = bar0[51];//total size h
					val[52] = bar0[52];//total size l					
					val[63] = bar0[63];//total size h
					val[64] = bar0[64];//total size l
					val[53] = bar0[53];//ddr3 used
					val[65] = bar0[65];//ddr3 used
					val[66] = bar0[66];//ch0 dmasize
					val[67] = bar0[67];//ch1 dmasize
					
					printf("-->ISR :   			%x\n",val[2]);	
					printf("-->Channle0 Data Rate L :   	%d\n",val[46]);
					printf("-->Channle0 I PN error count:  %d\n",512*val[47]+val[48]);
					printf("-->Channle0 record size:   	%d MB\n",512*val[51]+val[52]/1024/1024/8);
					printf("-->Channle0 ddr3 memory used:   %6.3f MB\n",(double)val[53]/1024/1024);
					printf("-->Channle0 dma size: %d\n",val[66]);
					printf("\n");
					printf("-->Channle1 Data Rate L :       %d\n",val[58]);
					printf("-->Channle1 I PN error count:  %d\n",512*val[59]+val[60]);
					printf("-->Channle1 record size:       %d MB\n",512*val[63]+val[64]/1024/1024/8);
					printf("-->Channle1 ddr3 memory used:   %6.3f MB\n",(double)val[65]/1024/1024);
					printf("-->Channle1 dma size: %d\n",val[67]);
					printf("\n");
				}
				// Reset stats
				Stat_TxTotalCount = 0;
				Stat_TxTotalBytes = 0;

				// Check for user cancel
				if (Cons_kbhit()){
					if (Cons_getch() == 27)//ESC
						goto _ExitDmaTest;

					if (Cons_getch() == 112){//p
						usleep(2000);						
					}
				}
				// Get new start time
				ftime( &StartTime );
			}
		}

		if(((val[2] & XDK7_INT_CH0) == XDK7_INT_CH0) && CH0_FLAG && CH0_PAUSE){			
			if (bInterrupts){	
				bar0[XDK7_INT_ENABLE] = XDK7_INT_US | XDK7_INT_US_TIMEOUT;
			}
			else{
				bar0[XDK7_INT_ENABLE] = XDK7_POLL_US | XDK7_POLL_US_TIMEOUT;
			}

			dma0.src_addr_h = 0x00000000;
			dma0.src_addr_l = CH0_DMA_LOCAL_ADDR;						
			dma0.dst_addr_h = 0x00000000;
			dma0.dst_addr_l = km0.pa;
			dma0.length = buf_len;		
			dma0.next_bda_h = 0x00000000;
			dma0.next_bda_l = 0x00000000;			
			dma0.control = 0x03020000;			
			
			write_dma(bar0, dma0);
			
			if(Channel_option == 3){
				CH0_FLAG = 0;
				CH1_FLAG = 1;
			}
			
			if (bInterrupts){					

				iRet = pd_waitForInterrupt(dev,XDK7_IRQ_US);

				//printf("  DMA ch0 pd_waitForInterrupt return value = %d\n",iRet);
				if(!iRet){
					val[2] = bar0[XDK7_INT_STAT];
					//printf("  DMA Interupts received ch0 ISR = %x\n",val[2]);				
					//bar0[XDK7_INT_ENABLE] = 0x0;	//clear int enable		
					if((val[2] & XDK7_INT_US_TIMEOUT) == XDK7_INT_US_TIMEOUT){
						printf("  Waiting DAQ timeout\n");
						goto _ExitDmaTest;
					}
				}else{
					//printf("  Waiting DMA0 Other Int, ISR = %x\n",val[2]);	
					goto _ExitDmaTest;
				}

				//DMA channel reset
				bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;

				iRet1 = LB_LoopBufferDataWrite1((unsigned char*)ptr0);

				if(iRet1){
						printf ("   Ch1 Buffer overflow, Exit\n");
						goto _ExitDmaTest;
					}

				blockcount1++;
				if(blockcount1 == DMATimes){						
					blockcount1=0;
					m_iCount1++;
					m_iTotalCount1++;						
				}
				
				if(m_iCount1 == LoopBufferBlockCount)//DMATimes
					m_iCount1=0;						
				
			}
			else {
				do{	
					val[2] = bar0[XDK7_INT_STAT];
					
					sleep(0);	
					if ((val[2] & XDK7_POLL_US_TIMEOUT) == XDK7_POLL_US_TIMEOUT){
						printf("*ERROR* - Timeout waiting for DMA0 to complete\n");
						goto _ExitDmaTest;					
					}
				}while ((val[2] & XDK7_POLL_US) != XDK7_POLL_US);
				
					//DMA channel reset
					bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;


					iRet1 = LB_LoopBufferDataWrite1((unsigned char*)ptr0);

					/*if(iRet1 == 1){
						printf ("  Ch1 Buffer Almost Full, Pause Ch1\n");
					}
					else if(iRet1 == 2){*/
					if(iRet1){
						printf ("   Ch1 Buffer overflow, Exit\n");
						goto _ExitDmaTest;
					}
						
					blockcount1++;
					if(blockcount1 == DMATimes){						
						blockcount1=0;
						m_iCount1++;
						m_iTotalCount1++;						
					}
					
					if(m_iCount1 == LoopBufferBlockCount)//DMATimes
						m_iCount1=0;
				//}
			}
			Stat_TxTotalCount++;
			Stat_TxTotalBytes += buf_len;
			LoopCount++;			
		}
		
		else if(((val[2] & XDK7_INT_CH1) == XDK7_INT_CH1) && CH1_FLAG && CH1_PAUSE)	{
	
			if (bInterrupts){	
				bar0[XDK7_INT_ENABLE] = XDK7_INT_US | XDK7_INT_US_TIMEOUT;
			}
			else{
				bar0[XDK7_INT_ENABLE] = XDK7_POLL_US | XDK7_POLL_US_TIMEOUT;
			}
		
			dma1.src_addr_h = 0x00000000;
			dma1.src_addr_l = CH1_DMA_LOCAL_ADDR;			
			dma1.dst_addr_h = 0x00000000;
			dma1.dst_addr_l = km1.pa;
			dma1.length = buf_len;
			dma1.next_bda_h = 0x00000000;
			dma1.next_bda_l = 0x00000000;
			dma1.control = 0x03020000;
			
			write_dma(bar0, dma1);

			if(Channel_option == 3){
				CH0_FLAG = 1;
				CH1_FLAG = 0;
			}
			
			if (bInterrupts){	
			
				iRet = pd_waitForInterrupt(dev,XDK7_IRQ_US);


				if(!iRet){
					//printf("  DMA ch1 pd_waitForInterrupt return value = %d\n",iRet);
					val[2] = bar0[XDK7_INT_STAT];
					//printf("  DMA Interupts received ch1 ISR = %x\n",val[2]);
				
					//bar0[XDK7_INT_ENABLE] = 0x0;	//clear int enable
					if((val[2] & XDK7_INT_US_TIMEOUT) == XDK7_INT_US_TIMEOUT){
						printf("  Waiting DAQ timeout\n");
						goto _ExitDmaTest;
					}
				}else{
					//printf("  Waiting DMA1 Other Int, ISR = 0x%x\n",val[2]);	
					goto _ExitDmaTest;
				}	

				//DMA channel reset
				bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;

				iRet2 = LB_LoopBufferDataWrite2((unsigned char*)ptr1);
				blockcount2++;
				if(blockcount2 == DMATimes)
				{
					blockcount2=0;
					m_iCount2++;
					m_iTotalCount2++;
				}
				if(m_iCount2 == LoopBufferBlockCount)//DMATimes
					m_iCount2=0;							
			}
			else{
				do{	
					val[2] = bar0[XDK7_INT_STAT];
					sleep(0);	
					if ((val[2] & XDK7_POLL_US_TIMEOUT) == XDK7_POLL_US_TIMEOUT){
						printf("*ERROR* - Timeout waiting for DMA1 to complete\n");
						goto _ExitDmaTest;					
					}
				}while ((val[2] & XDK7_POLL_US) != XDK7_POLL_US);
				//DMA channel reset
				bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;

				iRet2 = LB_LoopBufferDataWrite2((unsigned char*)ptr1);
				/*if(iRet2 == 1){
					printf ("  Ch2 Buffer Almost Full, Pause Ch2\n");				
				}
				else if(iRet2 == 2){*/
				if(iRet2){
					printf ("  Ch2 Buffer OverFlow, Exit\n");
					goto _ExitDmaTest;
				}

				blockcount2++;
				if(blockcount2 == DMATimes)
				{
					blockcount2=0;
					m_iCount2++;
					m_iTotalCount2++;
				}
				if(m_iCount2 == LoopBufferBlockCount)//DMATimes
					m_iCount2=0;
				//}
			}
			Stat_TxTotalCount++;
			Stat_TxTotalBytes += buf_len;
			LoopCount++;	
		}		
		
	} while (1);

_ExitDmaTest:
    	printf("\n       ------------------\n");
	
	pd_clearInterruptQueue(dev,XDK7_IRQ_US);
	pd_clearInterruptQueue(dev,XDK7_IRQ_IG);
	//pd_clearInterruptQueue(dev,XDK7_IRQ_CH0);
	//pd_clearInterruptQueue(dev,XDK7_IRQ_CH1);
	//pd_clearInterruptQueue(dev,XDK7_IRQ_DAQ);

	printf("  Stop DAQ.... \n");
	//write the control reg to clear the error and total_size register
	bar0[XDK7_CH0_CTRL] = XDK7_CH0_CTRL_CLEAR;
	bar0[XDK7_CH1_CTRL] = XDK7_CH0_CTRL_CLEAR;
	
	//Reset fifo		
	bar0[XDK7_FIFO_CTRL] = XDK7_RESET;

	printf("  pd_freeKernelMemory km0.... ");
	ret = pd_freeKernelMemory( &km0 );
	if (ret < 0){
		printf("*ERROR* - pd_freeKernelMemory km0 failed\n");
	}
	else{
		printf("Ok\n");	
	}
	
	printf("  pd_freeKernelMemory km1.... ");
	ret = pd_freeKernelMemory( &km1 );
	if (ret < 0){
		printf("*ERROR* - pd_freeKernelMemory km1 failed\n");
	}
	else{
		printf("Ok\n");	
	}
	
    if (bInterrupts){
		// Release the interrupt wait object
		printf("  Clear Int ...\n ");
		bar0[XDK7_INT_ENABLE] = 0;
    }

    	printf("  Reset upstream DMA ..............\n");
	bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;
	
	printf("  Unmap Bars ..............\n");
	/* unmap BARs */
	pd_unmapBAR( dev,0, bar0 );
	//pd_unmapBAR( dev,1, bar1 );
	pd_unmapBAR( dev,2, bar2 );
	
	m_bRAIDThread1 = 0;
	m_bRAIDThread2 = 0;
	
	printf("  Close files ..............\n");
	fclose(fp0);
	fclose(fp1);
	
	printf("  Delete Loops ..............\n");
	LoopBufferDel1();
	LoopBufferDel2();
	
	return;
}
/********************************************************************


 *********************************************************************/
void UDMARead(pd_device_t *dev) {
	int i,j,ret;
	unsigned int 		val[MAX];
	unsigned int 		*bar0;
	//unsigned int 		*bar1;
	unsigned long 		*bar2;
	
	pd_umem_t um0,um1;

	unsigned int		UserInput;
    unsigned int		int_reg;
    unsigned int		LoopCount;
   	unsigned long		PollCount;
    unsigned int		ElapsedTime_ms;
   	double				Stat_TxTotalCount;
    double				Stat_TxTotalBytes;
    struct timeb		StartTime, EndTime;
	struct timeb		LoopStartTime, LoopEndTime;
   	bool           		bInterrupts;
	unsigned int		ControlValue;	
	int					int_count;
	int 				Channel_option;
	int					iRet,iRet0,iRet1;

	m_iTotalCount1=0;
	m_iCount1=0;
	m_iTotalCount2=0;
	m_iCount2=0;
	blockcount1 = 0;
	blockcount2 = 0;
	m_bRAIDThread1 = 1;	
	m_bRAIDThread2 = 1;
	LoopCount = 0;
	Stat_TxTotalCount = 0;
	Stat_TxTotalBytes = 0;
	
	
	printf("-->Testing DMA Reading(Upstream) with User Memory... \n");
	
	printf("  Map BAR 0 for register access..\n ");
	bar0 = pd_mapBAR( dev, 0 );
	//bar1 = pd_mapBAR( dev, 1 );
	bar2 = pd_mapBAR( dev, 2 );
	
    // Determine whether to use interrupts or polling
	printf("  Use interrupts(i) or poll(p) [i/p]? --> ");	
	UserInput = getchar();

	if (UserInput == 'i' || UserInput == 'I')
		bInterrupts = 1;
	else
		bInterrupts = 0;

	if(bInterrupts){
		printf("  Use interrupts(i) mode\n");	
		pd_clearInterruptQueue(dev,XDK7_IRQ_US);
		pd_clearInterruptQueue(dev,XDK7_IRQ_IG);
//		pd_clearInterruptQueue(dev,XDK7_IRQ_CH0);
//		pd_clearInterruptQueue(dev,XDK7_IRQ_CH1);
//		pd_clearInterruptQueue(dev,XDK7_IRQ_DAQ);
	}

	printf("  which channel to test? 1:ch1,\t2:ch2,\t3:both --> ");	
	
	iRet = scanf("%d", &Channel_option);
	if(iRet<1){
		printf("-->Invalid Option\n");
		return;
	}
	else{
		//printf("-->Channel_option:%d\n",Channel_option);
	}

    	getchar();		

	if (Channel_option == 1){
		CH0_FLAG = 1;
		CH1_FLAG = 0;
		printf("\tTest ch1\n");
	}
	else if(Channel_option == 2){
		CH0_FLAG = 0;
		CH1_FLAG = 1;
		printf("\tTest ch2\n");
	}
	else if(Channel_option == 3){
		CH0_FLAG = 1;
		CH1_FLAG = 0;
		printf("\tTest both ch\n");
	}else{
		printf("-->Invalid Option\n");
		return;
	}

	CH0_PAUSE = 1;
	CH1_PAUSE = 1;
	
	printf("  ControlRegister Value in hex format:\n-->0x");
	scanf("%x", &ControlValue);
	
	getchar();
	
	printf("  Initial Loop Buffer.........\n ");
	LoopBufferInit1();
	LoopBufferInit2();
	
	printf("  UserMemory posix_memalign ......... ");
	
	if ((posix_memalign( (void**)&ptr0, 16, buf_len ) != 0) ||
		(posix_memalign( (void**)&ptr1, 16, buf_len ) != 0)	){
		printf("failed\n");
		return;
	}
	else {
		printf("ok\n");
	}
	
	printf("  Alloc UserMemory SGList.........");	
	
	iRet0 = pd_mapUserMemory(dev,ptr0,buf_len,&um0);
	iRet1 = pd_mapUserMemory(dev,ptr1,buf_len,&um1);
	if(	(iRet0 != 0) || (iRet1 != 0)	){		
		printf("failed\n");
		pd_unmapBAR( dev,0, bar0 );
		//pd_unmapBAR( dev,1, bar1 );
		pd_unmapBAR( dev,2, bar2 );
		return;
	}
	else {
		printf("ok\n");
		printf("ch0 Usermemory nents: %d, size = %ld\n",um0.nents,um0.size);
		printf("ch1 Usermemory nents: %d, size = %ld\n",um1.nents,um1.size);
	}
	
	//bda_t dma0[um0.nents],dma1[um1.nents];
	//pd_kmem_t km0[um0.nents],km1[um0.nents];	
	bda_t *dma0,*dma1;
	//pd_kmem_t km0,km1;
	pd_umem_t um_dma0,um_dma1;
	//void *pdma0= dma0;
	//void *pdma1= dma1;
	//unsigned long *p = NULL;
	bda_t *p = NULL;
	
	printf("  Descriptor posix_memalign ......... ");
	
	if ((posix_memalign( (void**)&dma0, 16, sizeof(bda_t)*um0.nents ) != 0) ||
		(posix_memalign( (void**)&dma1, 16, sizeof(bda_t)*um1.nents ) != 0)	){
		printf("failed\n");
		return;
	}
	else {
		printf("ok\n");
	}
	
	printf("Alloc Descriptor List.........");
	
			

/*	
	for(i=0;i<um0.nents;i++)	{	
		dma0[i] = (unsigned long)pd_allocKernelMemory( dev, sizeof(bda_t), &km0[i] );
		dma1[i] = (unsigned long)pd_allocKernelMemory( dev, sizeof(bda_t), &km1[i] );
	}
*/
	//dma0 = (bda_t *)pd_allocKernelMemory( dev, sizeof(bda_t)*um0.nents, &km0 );
	//dma1 = (bda_t *)pd_allocKernelMemory( dev, sizeof(bda_t)*um1.nents, &km1 );
	
	iRet0 = pd_mapUserMemory(dev,(void *)dma0,sizeof(bda_t)*um0.nents,&um_dma0);
	iRet1 = pd_mapUserMemory(dev,(void *)dma1,sizeof(bda_t)*um1.nents,&um_dma1);
	if(	(iRet0 != 0) || (iRet1 != 0)	){		
		printf("failed\n");
		pd_unmapBAR( dev,0, bar0 );
		//pd_unmapBAR( dev,1, bar1 );
		pd_unmapBAR( dev,2, bar2 );
		return;
	}
	else {
		printf("ok\n");
		printf("sizeof(bda_t) = %d\n",sizeof(bda_t));	
		printf("sizeof(unsigned int) = %d\n",sizeof(unsigned int));	
		printf("sizeof(unsigned long) = %d\n",sizeof(unsigned long));	
		printf("ch0 Descriptor nents: %d, size = %ld\n",um_dma0.nents,um_dma0.size);
		printf("ch1 Descriptor nents: %d, size = %ld\n",um_dma1.nents,um_dma1.size);
	}
			

	for(i=0;i<um0.nents;i++)	{	
		dma0[i].src_addr_h = 0x00000000;
		dma0[i].src_addr_l = CH0_DMA_LOCAL_ADDR;				
		dma0[i].dst_addr_h = 0x00000000;
		dma0[i].dst_addr_l = um0.sg[i].addr;		
		dma0[i].next_bda_h = 0x00000000;
		dma0[i].length = um0.sg[i].size;
		if(i==um0.nents-1){	
			dma0[i].next_bda_l = 0x00000000;
			dma0[i].control = 0x03020000;
			}
		else{			
			dma0[i].next_bda_l = um_dma0.sg[0].addr + (i+1)*sizeof(bda_t);
			dma0[i].control = 0x02020000;			
			}
	}	
	//pd_syncKernelMemory(&km0,0);	
	pd_syncUserMemory(&um_dma0,0);
	
	for(i=0;i<um0.nents;i++)	{			
		printf("dma0[%d].src_addr_l = %x\n",i,dma0[i].src_addr_l);
		printf("dma0[%d].dst_addr_l = %x\n",i,dma0[i].dst_addr_l);
		printf("dma0[%d].length = %x\n",i,dma0[i].length);
		printf("dma0[%d].next_bda_l = %lx\n",i,dma0[i].next_bda_l);
		printf("dma0[%d].control = %x\n",i,dma0[i].control);
	
	}

	for(i=0;i<um1.nents;i++)	{		
		dma1[i].src_addr_h = 0x00000000;
		dma1[i].src_addr_l = CH1_DMA_LOCAL_ADDR;		
		dma1[i].dst_addr_h = 0x00000000;
		dma1[i].dst_addr_l = um1.sg[i].addr;
		dma1[i].length = um1.sg[i].size;		
		dma1[i].next_bda_h = 0x00000000;		
		//dma1[i].next_bda_l = CH1_DMA_LOCAL_ADDR;	
		//dma1[i].next_bda_l = 0x00000000;
		//dma1[i].control = 0x03020000;
				
		if(i==um1.nents-1){			
			
			dma1[i].next_bda_l =  0x00000000;	
			dma1[i].control = 0x03020000;
			}
		else{			
			
			dma1[i].next_bda_l =  um_dma1.sg[0].addr+ (i+1) * sizeof(bda_t);//km1.pa + (i+1) * sizeof(bda_t);
			dma1[i].control = 0x02020000;
			}
			
	}
	//pd_syncKernelMemory(&km1,0);	
	pd_syncUserMemory(&um_dma1,0);	
	
	for(i=0;i<um1.nents;i++)	{			
		printf("dma1[%d].src_addr_l = %x\n",i,dma1[i].src_addr_l);
		printf("dma1[%d].dst_addr_l = %x\n",i,dma1[i].dst_addr_l);
		printf("dma1[%d].length = %x\n",i,dma1[i].length);
		printf("dma1[%d].next_bda_l = %lx\n",i,dma1[i].next_bda_l);
		printf("dma1[%d].control = %x\n",i,dma1[i].control);
	
	}	
		printf("  Open Files.........\n");
	if((fp0=fopen("/home/radi/rpdll/Data/ch0","wb"))==NULL)	{
		perror(NULL);
		printf("        -->Err: unable to open file ch0! \r\n");
	}
	else
		printf("      ch0 file open ok\n");
	
	
	if((fp1=fopen("/home/radi/rpdll/Data/ch1","wb"))==NULL){
		perror(NULL);
		printf("        -->Err: unable to open file ch1! \r\n");
	}
	else
		printf("      ch1 file open ok\n");

	printf("  Creating WriteFile Threads.........\n");
	memset(&thread, 0, sizeof(thread));          			
	if(pthread_create(&thread[0], NULL, thread1, NULL) != 0)      
			printf("      Create thread1 failed!\n");
	else
			printf("      Create thread1 ok\n");
	if(pthread_create(&thread[1], NULL, thread2, NULL) != 0)  
			printf("      Create thread2 failed");
	else
			printf("      Create thread2 ok\n");

	//Reset the DMA upstream channel
	bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;	

	bar0[XDK7_MRd_CTRL] = XDK7_RESET;
	bar0[XDK7_CplD_CTRL] = XDK7_RESET;
	//Reset fifo		
	bar0[XDK7_FIFO_CTRL] = XDK7_RESET;

	//Reset IGC
	bar0[XDK7_IG_CTRL] = XDK7_RESET;

	do{
		val[44] = bar0[44];
	
	}while(val[44] & DDR3_INIT_COMPLETED != DDR3_INIT_COMPLETED);

	do{
		val[56] = bar0[56];
	
	}while(val[56] & DDR3_INIT_COMPLETED != DDR3_INIT_COMPLETED);
		
	bar0[XDK7_CH0_DMASIZE]	= buf_len;
	bar0[XDK7_CH1_DMASIZE]	= buf_len;

	//write the control reg to start
	if (Channel_option == 1){
		bar0[XDK7_CH0_CTRL] = ControlValue;
	}
	else if (Channel_option == 2){
		bar0[XDK7_CH1_CTRL] = ControlValue;
	}
	else if (Channel_option == 3){
		bar0[XDK7_CH0_CTRL] = ControlValue;
		bar0[XDK7_CH1_CTRL] = ControlValue;
	}
	
	//printf(" ch0 CTRL= %x\n",bar0[XDK7_CH0_CTRL]);
	
	//goto _ExitDmaTest;
	
	ftime( &StartTime );		
	
	printf("-->DMA Read Start...\n");

	do {	
		
		if (bInterrupts){	
			if (Channel_option == 1){
				bar0[XDK7_INT_ENABLE] = XDK7_INT_IG | XDK7_INT_CH0 | XDK7_INT_CH0_TIMEOUT | XDK7_INT_DAQ | XDK7_INT_DAQ_TIMEOUT;
			}
			else if (Channel_option == 2){
				bar0[XDK7_INT_ENABLE] = XDK7_INT_IG | XDK7_INT_CH1 | XDK7_INT_CH1_TIMEOUT | XDK7_INT_DAQ | XDK7_INT_DAQ_TIMEOUT;
			}
			else if (Channel_option == 3){
				bar0[XDK7_INT_ENABLE] = XDK7_INT_IG | XDK7_INT_CH0 | XDK7_INT_CH1 | XDK7_INT_CH0_TIMEOUT | XDK7_INT_CH1_TIMEOUT | XDK7_INT_DAQ | XDK7_INT_DAQ_TIMEOUT;
			}
			
		}else{	
			bar0[XDK7_INT_ENABLE] = XDK7_INT_CH0 | XDK7_INT_CH1 | XDK7_INT_CH0_TIMEOUT | XDK7_INT_CH1_TIMEOUT | XDK7_INT_DAQ | XDK7_INT_DAQ_TIMEOUT;
		}
			
		
		bar0[XDK7_IG_LAT] = 0xFA;//0xFA = 250  * 4ns = 1us,

		if (bInterrupts){
			iRet = pd_waitForInterrupt(dev,XDK7_IRQ_IG);
			if(!iRet){
				val[2]	= bar0[XDK7_INT_STAT];				
				//printf(" DAQ IER= %x\n",bar0[4]);
				//printf(" DAQ Interupts received bar0[XDK7_INT_STAT]= %x\n",val[2]);
				//printf("-->Channle0 Control Statue  Register:   %x\n",bar0[44]);	
				//printf("-->Channle1 Control Statue  Register:   %x\n",bar0[56]);	
				//bar0[XDK7_IG_LAT] = 0x0;
				//bar0[XDK7_INT_ENABLE] = 0x0;	//clear int enable	
				if((val[2]  & XDK7_INT_DAQ_TIMEOUT) == XDK7_INT_DAQ_TIMEOUT){
					printf("  Waiting DAQ timeout\n");
					goto _ExitDmaTest;
				}
			}
			else{
				printf("  Waiting Int timeout\n");
				goto _ExitDmaTest;	
			}		
		}	
		else{
				 	 	 	
			do{	
				val[2]	= bar0[XDK7_INT_STAT];
				sleep(0);
				
				if((val[2]  & XDK7_INT_DAQ_TIMEOUT) == XDK7_INT_DAQ_TIMEOUT){
					printf("  Waiting DAQ timeout\n");
					goto _ExitDmaTest;
				}
			}while((val[2] & XDK7_INT_DAQ) != XDK7_INT_DAQ);	
							
		}
	  // Periodically display statistics
		if ((LoopCount & 0x0000003F) == 0){
			// Get end time
			ftime( &EndTime );

			// Calculate elapsed time in milliseconds
			ElapsedTime_ms = (((unsigned int)EndTime.time * 1000) + EndTime.millitm) -
							 (((unsigned int)StartTime.time * 1000) + StartTime.millitm);

			if (ElapsedTime_ms >= (UPDATE_DISPLAY_SEC * 1000)){
				// Display statistics
				if (ElapsedTime_ms != 0){
					printf(
						" Transfers: %0.0lf   Bytes: %0.2lf MB   Time: %ldms   Rate:%6.3lf MB/s\n",
						Stat_TxTotalCount, Stat_TxTotalBytes / (1 << 20), ElapsedTime_ms,
						((Stat_TxTotalBytes * 1000) / (double)ElapsedTime_ms) / (double)(1 << 20)
						);	
													
					val[46] = bar0[46];//rate
					val[47] = bar0[47];//error h
					val[48] = bar0[48];//error l
					val[58] = bar0[58];//rate
					val[59] = bar0[59];//error h					
					val[60] = bar0[60];//error l
					val[51] = bar0[51];//total size h
					val[52] = bar0[52];//total size l					
					val[63] = bar0[63];//total size h
					val[64] = bar0[64];//total size l
					val[53] = bar0[53];//ddr3 used
					val[65] = bar0[65];//ddr3 used
					val[66] = bar0[66];//ch0 dmasize
					val[67] = bar0[67];//ch1 dmasize
					
					printf("-->ISR :   			%x\n",val[2]);	
					printf("-->Channle0 Data Rate L :   	%d\n",val[46]);
					printf("-->Channle0 I PN error count:  %d\n",512*val[47]+val[48]);
					printf("-->Channle0 record size:   	%d MB\n",512*val[51]+val[52]/1024/1024/8);
					printf("-->Channle0 ddr3 memory used:   %6.3f MB\n",(double)val[53]/1024/1024);
					printf("-->Channle0 dma size: %d\n",val[66]);
					printf("\n");
					printf("-->Channle1 Data Rate L :       %d\n",val[58]);
					printf("-->Channle1 I PN error count:  %d\n",512*val[59]+val[60]);
					printf("-->Channle1 record size:       %d MB\n",512*val[63]+val[64]/1024/1024/8);
					printf("-->Channle1 ddr3 memory used:   %6.3f MB\n",(double)val[65]/1024/1024);
					printf("-->Channle1 dma size: %d\n",val[67]);
					printf("\n");
					
				}
				// Reset stats
				Stat_TxTotalCount = 0;
				Stat_TxTotalBytes = 0;

				// Check for user cancel
				if (Cons_kbhit()){
					if (Cons_getch() == 27)//ESC
						goto _ExitDmaTest;

					if (Cons_getch() == 112){//p
						usleep(2000);						
					}
				}
				// Get new start time
				ftime( &StartTime );
			}
		}
		
		
		if(((val[2] & XDK7_INT_CH0) == XDK7_INT_CH0) && CH0_FLAG && CH0_PAUSE){			
			if (bInterrupts){	
				bar0[XDK7_INT_ENABLE] = XDK7_INT_US | XDK7_INT_US_TIMEOUT;
			}
			else{
				bar0[XDK7_INT_ENABLE] = XDK7_POLL_US | XDK7_POLL_US_TIMEOUT;
			}

			write_dma(bar0, dma0[0]);
					
			if(Channel_option == 3){
				CH0_FLAG = 0;
				CH1_FLAG = 1;
			}
			
			if (bInterrupts){					

				iRet = pd_waitForInterrupt(dev,XDK7_IRQ_US);				

				//printf("dma0 statue = %x\n",bar0[19]);
				
				//printf("  DMA ch0 pd_waitForInterrupt return value = %d\n",iRet);
				if(!iRet){
					val[2] = bar0[XDK7_INT_STAT];
					//printf("  DMA Interupts received ch0 ISR = %x\n",val[2]);				
					//bar0[XDK7_INT_ENABLE] = 0x0;	//clear int enable		
					if((val[2] & XDK7_INT_US_TIMEOUT) == XDK7_INT_US_TIMEOUT){
						printf("  Waiting DMA0 timeout\n");
						goto _ExitDmaTest;
					}
				}else{
					printf("  Waiting DMA0 Other Int, ISR = %x\n",val[2]);	
					goto _ExitDmaTest;
				}

				//DMA channel reset
				bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;
				
				pd_syncUserMemory(&um0,2);
				
				iRet1 = LB_LoopBufferDataWrite1((unsigned char*)um0.vma);

				if(iRet1){
						printf ("   Ch1 Buffer overflow, Exit\n");
						goto _ExitDmaTest;
					}

				blockcount1++;
				if(blockcount1 == DMATimes){						
					blockcount1=0;
					m_iCount1++;
					m_iTotalCount1++;						
				}
				
				if(m_iCount1 == LoopBufferBlockCount)//DMATimes
					m_iCount1=0;						
				
			}
			else {
				do{	
					val[2] = bar0[XDK7_INT_STAT];
					
					sleep(0);	
					if ((val[2] & XDK7_POLL_US_TIMEOUT) == XDK7_POLL_US_TIMEOUT){
						printf("*ERROR* - Timeout waiting for DMA0 to complete\n");
						goto _ExitDmaTest;					
					}
				}while ((val[2] & XDK7_POLL_US) != XDK7_POLL_US);
				
					//DMA channel reset
					bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;
					
					pd_syncUserMemory(&um0,2);

					iRet1 = LB_LoopBufferDataWrite1((unsigned char*)um0.vma);

					/*if(iRet1 == 1){
						printf ("  Ch1 Buffer Almost Full, Pause Ch1\n");
					}
					else if(iRet1 == 2){*/
					if(iRet1){
						printf ("   Ch1 Buffer overflow, Exit\n");
						goto _ExitDmaTest;
					}
						
					blockcount1++;
					if(blockcount1 == DMATimes){						
						blockcount1=0;
						m_iCount1++;
						m_iTotalCount1++;						
					}
					
					if(m_iCount1 == LoopBufferBlockCount)//DMATimes
						m_iCount1=0;
				//}
			}
			Stat_TxTotalCount++;
			Stat_TxTotalBytes += buf_len;
			LoopCount++;			
		}
		
		else if(((val[2] & XDK7_INT_CH1) == XDK7_INT_CH1) && CH1_FLAG && CH1_PAUSE)	{
	
			if (bInterrupts){	
				bar0[XDK7_INT_ENABLE] = XDK7_INT_US | XDK7_INT_US_TIMEOUT;
			}
			else{
				bar0[XDK7_INT_ENABLE] = XDK7_POLL_US | XDK7_POLL_US_TIMEOUT;
			}

			write_dma(bar0, dma1[0]);
			
			if(Channel_option == 3){
				CH0_FLAG = 1;
				CH1_FLAG = 0;
			}
			
			if (bInterrupts){	
			
				iRet = pd_waitForInterrupt(dev,XDK7_IRQ_US);

				//printf("dma1.length = %x\n",bar0[17]);
				
				if(!iRet){
					//printf("  DMA ch1 pd_waitForInterrupt return value = %d\n",iRet);
					val[2] = bar0[XDK7_INT_STAT];
					//printf("  DMA Interupts received ch1 ISR = %x\n",val[2]);
				
					//bar0[XDK7_INT_ENABLE] = 0x0;	//clear int enable
					if((val[2] & XDK7_INT_US_TIMEOUT) == XDK7_INT_US_TIMEOUT){
						printf("  Waiting DMA1 timeout\n");
						goto _ExitDmaTest;
					}					
				}else{
					printf("  Waiting DMA1 Other Int, ISR = 0x%x\n",val[2]);	
					goto _ExitDmaTest;
				}	

				//DMA channel reset
				bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;
							
				pd_syncUserMemory(&um1,2);
	
				iRet2 = LB_LoopBufferDataWrite2((unsigned char*)um1.vma);
				blockcount2++;
				if(blockcount2 == DMATimes)
				{
					blockcount2=0;
					m_iCount2++;
					m_iTotalCount2++;
				}
				if(m_iCount2 == LoopBufferBlockCount)//DMATimes
					m_iCount2=0;							
			}
			else{
				do{	
					val[2] = bar0[XDK7_INT_STAT];
					sleep(0);	
					if ((val[2] & XDK7_POLL_US_TIMEOUT) == XDK7_POLL_US_TIMEOUT){
						printf("*ERROR* - Timeout waiting for DMA1 to complete\n");
						goto _ExitDmaTest;					
					}
				}while ((val[2] & XDK7_POLL_US) != XDK7_POLL_US);
				//DMA channel reset
				bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;

				pd_syncUserMemory(&um1,2);
				
				iRet2 = LB_LoopBufferDataWrite2((unsigned char*)um1.vma);
				/*if(iRet2 == 1){
					printf ("  Ch2 Buffer Almost Full, Pause Ch2\n");				
				}
				else if(iRet2 == 2){*/
				if(iRet2){
					printf ("  Ch2 Buffer OverFlow, Exit\n");
					goto _ExitDmaTest;
				}

				blockcount2++;
				if(blockcount2 == DMATimes)
				{
					blockcount2=0;
					m_iCount2++;
					m_iTotalCount2++;
				}
				if(m_iCount2 == LoopBufferBlockCount)//DMATimes
					m_iCount2=0;
				//}
			}
			Stat_TxTotalCount++;
			Stat_TxTotalBytes += buf_len;
			LoopCount++;	
		}		
		
	} while (1);

_ExitDmaTest:
    	printf("\n       ------------------\n");
	
	pd_clearInterruptQueue(dev,XDK7_IRQ_US);
	pd_clearInterruptQueue(dev,XDK7_IRQ_IG);
	//pd_clearInterruptQueue(dev,XDK7_IRQ_CH0);
	//pd_clearInterruptQueue(dev,XDK7_IRQ_CH1);
	//pd_clearInterruptQueue(dev,XDK7_IRQ_DAQ);

	printf("  Stop DAQ.... \n");
	//write the control reg to clear the error and total_size register
	bar0[XDK7_CH0_CTRL] = XDK7_CH0_CTRL_CLEAR;
	bar0[XDK7_CH1_CTRL] = XDK7_CH0_CTRL_CLEAR;
	
	//Reset fifo		
	bar0[XDK7_FIFO_CTRL] = XDK7_RESET;

	printf("  pd_freeUserMemory um0.... ");
	ret = pd_unmapUserMemory( &um0 );
	if (ret < 0){
		printf("*ERROR* - pd_freeUserMemory um0 failed\n");
	}
	else{
		printf("Ok\n");	
	}
	
	printf("  pd_freeUserMemory um1.... ");
	ret = pd_unmapUserMemory( &um1 );
	if (ret < 0){
		printf("*ERROR* - pd_freeUserMemory um1 failed\n");
	}
	else{
		printf("Ok\n");	
	}
	
	free(ptr0);
	free(ptr1);
	
    if (bInterrupts){
		// Release the interrupt wait object
		printf("  Clear Int ...\n ");
		bar0[XDK7_INT_ENABLE] = 0;
    }

    	printf("  Reset upstream DMA ..............\n");
	bar0[XDK7_US_CTRL] = XDK7_DMA_RESET;
	
	printf("  Unmap Bars ..............\n");
	/* unmap BARs */
	pd_unmapBAR( dev,0, bar0 );
	//pd_unmapBAR( dev,1, bar1 );
	pd_unmapBAR( dev,2, bar2 );
	
	m_bRAIDThread1 = 0;
	m_bRAIDThread2 = 0;
	
	printf("  Close files ..............\n");
	fclose(fp0);
	fclose(fp1);
	
	printf("  Delete Loops ..............\n");
	LoopBufferDel1();
	LoopBufferDel2();
	
	return;
}

//-------------------------------------------------thread-------------------------------------------------
void *thread1(){
    //printf ("   thread1 : thread 1 created\n");
		
	while (m_bRAIDThread1){
		if (m_iTotalWriteBlockID1 - m_iRAIDTotalReadBlockID1 >= 1){			
			fwrite(m_pRawDataBuffer1 + m_lRAIDReadPointer1, WriteSize, 1, fp0);
			//printf ("   thread1 : write ch0\n");
			m_lRAIDReadPointer1 += WriteSize;
			m_llRAIDTotalReadPointer1 += WriteSize;
			m_iCounter1++;
			if (m_iCounter1 == WriteTimes){	
				m_iCounter1 = 0;
				m_iRAIDReadBlockID1++;
				m_iRAIDTotalReadBlockID1++;
				LB_PositionReadPointer1();
				//printf ("   thread1 : move ch0 read pointer\n");
			}
			//usleep(1);			
		} 	
		else if(iRet1){
			printf("CH1 R~Buffer is over~\n");
		}	
		else{	//CH0_PAUSE = 1;		
			sleep(0);
		}	
	}
	pthread_exit(NULL);
	return 0;	
  
}

void *thread2(){
    //printf ("   thread2 : thread 2 created\n");
		
	while (m_bRAIDThread2)	{
		if (m_iTotalWriteBlockID2 - m_iRAIDTotalReadBlockID2 >= 1){	
				
			fwrite(m_pRawDataBuffer2 + m_lRAIDReadPointer2, WriteSize, 1, fp1);
			m_lRAIDReadPointer2 += WriteSize;
			m_llRAIDTotalReadPointer2 += WriteSize;
			m_iCounter2++; 
			if (m_iCounter2 == WriteTimes)		{
				m_iCounter2 = 0;
				m_iRAIDReadBlockID2++;
				m_iRAIDTotalReadBlockID2++;
				LB_PositionReadPointer2();
			}
			//usleep(1);
		} 
		else if(iRet2){
			printf("CH2 R~Buffer is over~\n");
		}
		else{	//CH1_PAUSE = 1;			
			sleep(0);
		}		
	}
	pthread_exit(NULL);
	return 0;
}
//---------------------------------loopbuffer---------------------------------------------------

void LoopBufferInit1(){
	m_iBlockSize1=LoopBufferSize;
	m_iBlockCount1=LoopBufferBlockCount;
	m_iTotalSize1=m_iBlockSize1*(m_iBlockCount1-1);

	m_pRawDataBuffer1= (unsigned char*)malloc(m_iBlockSize1*m_iBlockCount1);
	printf ("      LoopBufferInit1 : malloc ok\n");
	
	m_llRAIDTotalReadPointer1 = 0;
	m_lRAIDReadPointer1 = 0;
	m_iRAIDTotalReadBlockID1 = 0;
	m_iRAIDReadBlockID1 = 0;	

	m_llTotalWritePointer1 = 0;
	m_lWritePointer1 = 0;
	m_iTotalWriteBlockID1 = 0;
	m_iWriteBlockID1 = 0;

	m_llRAIDTotalWritePointer1 = 0;
	m_lRAIDWritePointer1 = 0;
	m_iRAIDTotalWriteBlockID1 = 0;
	m_iRAIDWriteBlockID1 = 0;	

}

void LoopBufferInit2(){
	m_iBlockSize2=LoopBufferSize;
	m_iBlockCount2=LoopBufferBlockCount;
	m_iTotalSize2=m_iBlockSize2*(m_iBlockCount2-1);

	m_pRawDataBuffer2= (unsigned char*)malloc(m_iBlockSize2*m_iBlockCount2);
	printf ("       LoopBufferInit2 : malloc ok\n");
	
	m_llRAIDTotalReadPointer2 = 0;
	m_lRAIDReadPointer2 = 0;
	m_iRAIDTotalReadBlockID2 = 0;
	m_iRAIDReadBlockID2 = 0;	

	m_llTotalWritePointer2 = 0;
	m_lWritePointer2 = 0;
	m_iTotalWriteBlockID2 = 0;
	m_iWriteBlockID2 = 0;

	m_llRAIDTotalWritePointer2 = 0;
	m_lRAIDWritePointer2 = 0;
	m_iRAIDTotalWriteBlockID2 = 0;
	m_iRAIDWriteBlockID2 = 0;	

}

void LoopBufferDel1(){
	free(m_pRawDataBuffer1);
}

void LoopBufferDel2(){
	free(m_pRawDataBuffer2);
}

unsigned char LB_LoopBufferDataWrite1(unsigned char* buffer){

	if((m_llTotalWritePointer1-m_llRAIDTotalReadPointer1) > m_iTotalSize1){		
		//CH0_PAUSE = 0;
		return 1;
	}
	/*else if((m_llTotalWritePointer1-m_llRAIDTotalReadPointer1) > m_iTotalSize1){		
		return 2;
	}
	*/

	memcpy(m_pRawDataBuffer1+m_lWritePointer1,buffer,buf_len);
	
	m_lWritePointer1 += buf_len;
	if(m_lWritePointer1==m_iBlockSize1*m_iBlockCount1)	{
		m_lWritePointer1=0;
	}
	m_llTotalWritePointer1=m_llTotalWritePointer1+buf_len;
	m_iWriteBlockID1 = m_iCount1;
	m_iTotalWriteBlockID1 = m_iTotalCount1;
	return 0;
}

unsigned char LB_LoopBufferDataWrite2(unsigned char* buffer){
	if((m_llTotalWritePointer2 - m_llRAIDTotalReadPointer2) > m_iTotalSize2){		
		//CH1_PAUSE = 0;
		return 1;
	}
	/*else if((m_llTotalWritePointer2 - m_llRAIDTotalReadPointer2) > m_iTotalSize2){			
		return 2;
	}*/


	memcpy(m_pRawDataBuffer2+m_lWritePointer2,buffer,buf_len);
	
	m_lWritePointer2 += buf_len;
	if(m_lWritePointer2==m_iBlockSize2*m_iBlockCount2)	{
		m_lWritePointer2=0;
	}
	m_llTotalWritePointer2=m_llTotalWritePointer2+buf_len;
	m_iWriteBlockID2 = m_iCount2;
	m_iTotalWriteBlockID2 = m_iTotalCount2;
	return 0;
}

void LB_PositionReadPointer1(){
	if (m_iBlockCount1==m_iRAIDReadBlockID1){
		m_iRAIDReadBlockID1 = 0;
		m_lRAIDReadPointer1 = 0;
		return;
	}
	else{
		return;
	}
}

void LB_PositionReadPointer2(){
	if (m_iBlockCount2==m_iRAIDReadBlockID2){
		m_iRAIDReadBlockID2 = 0;
		m_lRAIDReadPointer2 = 0;
		return;
	}
	else{
		return;
	}
}

void LB_ResetLoopBuffer1(){
	m_llRAIDTotalReadPointer1 = 0;
	m_lRAIDReadPointer1 = 0;
	m_iRAIDTotalReadBlockID1 = 0;
	m_iRAIDReadBlockID1 = 0;	

	m_llTotalWritePointer1 = 0;
	m_lWritePointer1 = 0;
	m_iTotalWriteBlockID1 = 0;
	m_iWriteBlockID1 = 0;

	m_llRAIDTotalWritePointer1 = 0;
	m_lRAIDWritePointer1 = 0;
	m_iRAIDTotalWriteBlockID1 = 0;
	m_iRAIDWriteBlockID1 = 0;	

}

void LB_ResetLoopBuffer2(){
	m_llRAIDTotalReadPointer2 = 0;
	m_lRAIDReadPointer2 = 0;
	m_iRAIDTotalReadBlockID2 = 0;
	m_iRAIDReadBlockID2 = 0;	

	m_llTotalWritePointer2 = 0;
	m_lWritePointer2 = 0;
	m_iTotalWriteBlockID2 = 0;
	m_iWriteBlockID2 = 0;

	m_llRAIDTotalWritePointer2 = 0;
	m_lRAIDWritePointer2 = 0;
	m_iRAIDTotalWriteBlockID2 = 0;
	m_iRAIDWriteBlockID2 = 0;	
}


/******************************************************************
 *
 * Function   :  Cons_kbhit
 *
 * Description:  Determines if input is pending
 *
 *****************************************************************/
int Cons_kbhit(void){
    int            count;
    struct timeval tv;
    struct termios Tty_Save;
    struct termios Tty_New;


    // Get current terminal attributes
    tcgetattr( STDIN_FILENO, &Tty_Save );

    // Copy attributes
    Tty_New = Tty_Save;

    // Disable canonical mode (handles special characters)
    Tty_New.c_lflag &= ~ICANON;

    // Disable character echo
    Tty_New.c_lflag &= ~ECHO;

    // Set timeouts
    Tty_New.c_cc[VMIN]  = 1;   // Minimum chars to wait for
    Tty_New.c_cc[VTIME] = 1;   // Minimum wait time

    // Set new terminal attributes
    if (tcsetattr( STDIN_FILENO, TCSANOW, &Tty_New ) != 0)
        return 0;

    // Set to no characters pending
    count = 0;

    // Check stdin for pending characters
    if (ioctl( STDIN_FILENO, FIONREAD, &count ) != 0)
        return 0;

    // Restore old settings
    tcsetattr( STDIN_FILENO, TCSANOW, &Tty_Save );

    // Small delay needed to give up CPU slice & allow use in a tight loop
    tv.tv_sec  = 0;
    tv.tv_usec = 1;
    select(1, NULL, NULL, NULL, &tv);

    return count;
}

/******************************************************************
 *
 * Function   :  Cons_getch
 *
 * Description:  Gets a character from the keyboard (with blocking)
 *
 *****************************************************************/
int
Cons_getch(
    void
    )
{
    int            retval;
    char           ch;
    struct termios Tty_Save;
    struct termios Tty_New;


    // Make sure all output data is flushed
    fflush( stdout );

    // Get current terminal attributes
    tcgetattr( STDIN_FILENO, &Tty_Save );

    // Copy attributes
    Tty_New = Tty_Save;

    // Disable canonical mode (handles special characters)
    Tty_New.c_lflag &= ~ICANON;

    // Disable character echo
    Tty_New.c_lflag &= ~ECHO;

    // Set timeouts
    Tty_New.c_cc[VMIN]  = 1;   // Minimum chars to wait for
    Tty_New.c_cc[VTIME] = 1;   // Minimum wait time

    // Set new terminal attributes
    if (tcsetattr( STDIN_FILENO, TCSANOW, &Tty_New ) != 0)
        return 0;

    // Get a single character from stdin
    retval = read( STDIN_FILENO, &ch, 1 ); 

    // Restore old settings
    tcsetattr( STDIN_FILENO, TCSANOW, &Tty_Save );

    if (retval > 0)
        return (int)ch;

    return 0;
}


void write_dma(unsigned int *bar0, bda_t dma) {
	bar0[11] = dma.src_addr_h;
	bar0[12] = dma.src_addr_l;
	bar0[13] = dma.dst_addr_h;
	bar0[14] = dma.dst_addr_l;		
	bar0[15] = dma.next_bda_h;
	bar0[16] = dma.next_bda_l;
	bar0[17] = dma.length;
	bar0[XDK7_US_CTRL] = dma.control;	//control is written at the end, starts DMA
}
void ExamFile() 
{
	// TODO: Add your control notification handler code here
	FILE *fp;
	//int fp;
	long long FL;
	unsigned int DataToExam[FileLength];
	unsigned int LastWord;
	long long WrongNum;
	bool Exam;
	unsigned int ExamingWord;
	int j;
	int i;
	int ReadLength;	
	bool myEOF;

	printf("正在检查文件ch0...\n");
	WrongNum = 0;
	Exam = 1;
	j = 0;
	i = 1;
	fp = fopen("/home/radi/rpdll/Data/ch0","rb");
	fseeko(fp,0,SEEK_END);
	FL = ftello(fp);
	fseeko(fp,0,SEEK_SET);

	if (FL>=1024)
	{
		printf("file lenght is %d MB\n",FL/1024/1024);
	} 
	else
	{
		printf("file lenght is %d KB\n",FL/1024);
	}
 	
	if(FL == 0)
	{
		printf("文件为空\n");		
		fclose(fp);		
		Exam = 0;
		goto _check_channel2;
	}
	
	if(FL/4 >= FileLength)
		ReadLength = FileLength;
	else
		ReadLength = FL/4;


	while(Exam && ftello(fp)!=FL)
	{
		if(i==ReadLength)
			j++;
		
		LastWord = DataToExam[ReadLength-1];
		fread(DataToExam,sizeof(unsigned int)*ReadLength,1,fp);
		//read(fp,DataToExam,1);
		
		if( j && ( (DataToExam[0]-LastWord) != 0x01) )
		{
			WrongNum++;				
	printf("第%ld次错误在:\t第%ld行(0x%x)\t第%ld字节\n",WrongNum,j*ReadLength/4,j*ReadLength/4,j*ReadLength*4);
			if(WrongNum >20)
				break;
			
		}

		for(i=1; i<ReadLength; i++)
		{	
			ExamingWord = (i + j*ReadLength)/4;
			
			if(ExamingWord*16 < FL)
				myEOF = 0;
			else
				myEOF = 1;


			if((DataToExam[i]-DataToExam[i-1])!=0x01)
			{
				if(!myEOF)
				{
					WrongNum++;
	printf("第%ld次错误在:\t第%ld行(0x%x)\t第%ld字节\n",WrongNum,ExamingWord,ExamingWord,(j*ReadLength*4+i*4));
					if(WrongNum >20)
					break;
				}
			}
		
		}
		if(WrongNum >20)
			break;
		if(ftello(fp)==FL)
		{
			printf("检查完成\n");
			if(WrongNum == 0)
				printf("数据完全正确\n");
		}

	}
	
	fclose(fp);	

_check_channel2:
	printf("正在检查文件ch1...\n");
	WrongNum = 0;
	Exam = 1;
	j = 0;
	i = 1;
	fp = fopen("/home/radi/rpdll/Data/ch1","rb");
	fseeko(fp,0,SEEK_END);
	FL = ftello(fp);
	fseeko(fp,0,SEEK_SET);

	if (FL>=1024)
	{
		printf("file lenght is %d MB\n",FL/1024/1024);
	} 
	else
	{
		printf("file lenght is %d KB\n",FL/1024);
	}
 	
	if(FL == 0)
	{
		printf("文件为空\n");		
		fclose(fp);		
		Exam = 0;
		return;
	}
	
	if(FL/4 >= FileLength)
		ReadLength = FileLength;
	else
		ReadLength = FL/4;

	
	while(Exam && ftello(fp)!=FL)
	{
		if(i==ReadLength)
			j++;
		
		LastWord = DataToExam[ReadLength-1];
		fread(DataToExam,sizeof(unsigned int)*ReadLength,1,fp);
		//read(fp,DataToExam,1);

		if( j && ( (DataToExam[0]-LastWord) != 0x01) )
		{
			WrongNum++;				
	printf("第%ld次错误在:\t第%ld行(0x%x)\t第%ld字节\n",WrongNum,j*ReadLength/4,j*ReadLength/4,j*ReadLength*4);
			if(WrongNum >20)
				break;
			
		}

		for(i=1; i<ReadLength; i++)
		{	
			ExamingWord = (i + j*ReadLength)/4;
			
			if(ExamingWord*16 < FL)
				myEOF = 0;
			else
				myEOF = 1;


			if((DataToExam[i]-DataToExam[i-1])!=0x01)
			{
				if(!myEOF)
				{
					WrongNum++;
	printf("第%ld次错误在:\t第%ld行(0x%x)\t第%ld字节\n",WrongNum,ExamingWord,ExamingWord,(j*ReadLength*4+i*4));
					if(WrongNum >20)
					break;
				}
			}
		
		}
		if(WrongNum >20)
			break;
		if(ftello(fp)==FL)
		{
			printf("检查完成\n");
			if(WrongNum == 0)
				printf("数据完全正确\n");
		}

	}
	
	fclose(fp);

}


