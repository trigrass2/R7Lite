// LoopBuffer.h: interface for the CLoopBuffer class.
//
//////////////////////////////////////////////////////////////////////
class CLoopBuffer  
{
public:
	CLoopBuffer(int dwBlockSize,int iBlockCount);
	virtual ~CLoopBuffer();
//------------------------RAID�������ָ��------------------------------
public:	
	long long m_llRAIDTotalReadPointer;
	long	 m_lRAIDReadPointer;
	int      m_iRAIDTotalReadBlockID;
	int      m_iRAIDReadBlockID;	

//------------------------RAID�������ָ��------------------------------
public:	
	long long m_llRAIDTotalWritePointer;
	long	 m_lRAIDWritePointer;
	int      m_iRAIDTotalWriteBlockID;
	int      m_iRAIDWriteBlockID;	

//------------------------ʵʱ�����ָ��------------------------------
public:
	long long m_llNETTotalReadPointer;
	long	 m_lNETReadPointer;
	int      m_iNETTotalReadBlockID;
	int      m_iNETReadBlockID;	

	
//------------------------֡ͬ�����ָ��--------------------------------
public:
	long long m_llFSTotalReadPointer;
	long	 m_lFSReadPointer;
	int      m_iFSTotalReadBlockID;
	int      m_iFSReadBlockID;	

//------------------------дָ��----------------------------------------
public:
	long long m_llTotalWritePointer;
	long	 m_lWritePointer;
	int		 m_iTotalWriteBlockID;
	int		 m_iWriteBlockID;

//------------------------��ָ��----------------------------------------
public:
	long long m_llTotalReadPointer;
	long	 m_lReadPointer;
	int		 m_iTotalReadBlockID;
	int		 m_iReadBlockID;

public:
	void	LB_ResetLoopBuffer();			//��������ָ��
	void	LB_PositionReadPointer(int &iReadBlockID,long &lReadPointer);	//�����ָ��
	char	LB_LoopBufferDataWrite(char* pBuf,int iLen,int iWriteBlockID,int iTotalWriteBlockID);	//д���
	char	LB_LoopBufferDataRead(char* pBuf,int iLen,int iReadBlockID,int iTotalReadBlockID);	//�����

	char*	m_pRawDataBuffer;
	
private:
	int		m_iTotalSize;
	int		m_iBlockSize;
	int		m_iBlockCount;
};
