
#include "LoopBuffer.h"

//////////////////////////////////////////////////////////////////////
////           Construction/Destruction                           ////
//////////////////////////////////////////////////////////////////////
CLoopBuffer::CLoopBuffer(int iBlockSize,int iBlockCount)
{
	m_iBlockSize=iBlockSize;
	m_iBlockCount=iBlockCount;
	m_iTotalSize=m_iBlockSize*(m_iBlockCount-1);

	m_pRawDataBuffer=new BYTE[m_iBlockSize*m_iBlockCount];

	m_llRAIDTotalReadPointer = 0;
	m_lRAIDReadPointer = 0;
	m_iRAIDTotalReadBlockID = 0;
	m_iRAIDReadBlockID = 0;	

	m_llNETTotalReadPointer = 0;
	m_lNETReadPointer = 0;
	m_iNETTotalReadBlockID = 0;
	m_iNETReadBlockID = 0;	


	m_llFSTotalReadPointer = 0;
	m_lFSReadPointer = 0;
	m_iFSTotalReadBlockID = 0;
	m_iFSReadBlockID = 0;	

	m_llTotalWritePointer = 0;
	m_lWritePointer = 0;
	m_iTotalWriteBlockID = 0;
	m_iWriteBlockID = 0;

	m_llRAIDTotalWritePointer = 0;
	m_lRAIDWritePointer = 0;
	m_iRAIDTotalWriteBlockID = 0;
	m_iRAIDWriteBlockID = 0;	

	m_llTotalReadPointer = 0;
	m_lReadPointer = 0;
	m_iTotalReadBlockID = 0;
	m_iReadBlockID = 0;

}

CLoopBuffer::~CLoopBuffer()
{
	delete [] m_pRawDataBuffer;

}

BYTE CLoopBuffer::LB_LoopBufferDataWrite(BYTE* pBuf,int iLen,int iWriteBlockID,int iTotalWriteBlockID)
{
	if((m_llTotalWritePointer-m_llRAIDTotalReadPointer) > m_iTotalSize)//4MB
	{
		return 1;
	}

	memcpy(m_pRawDataBuffer+m_lWritePointer,pBuf,iLen);
	m_lWritePointer += iLen;
	if(m_lWritePointer==m_iBlockSize*m_iBlockCount)
	{
		m_lWritePointer=0;
	}
	m_llTotalWritePointer=m_llTotalWritePointer+iLen;
	m_iWriteBlockID = iWriteBlockID;
	m_iTotalWriteBlockID = iTotalWriteBlockID;
	return 0;
}


void CLoopBuffer::LB_PositionReadPointer(int &iReadBlockID,LONG &lReadPointer)
{
	if (iReadBlockID==m_iBlockCount)
	{
		iReadBlockID = 0;
		lReadPointer = 0;
		return;
	}
	else
	{
		return;
	}
}



void CLoopBuffer::LB_ResetLoopBuffer()
{
	m_llRAIDTotalReadPointer = 0;
	m_lRAIDReadPointer = 0;
	m_iRAIDTotalReadBlockID = 0;
	m_iRAIDReadBlockID = 0;	

	m_llNETTotalReadPointer = 0;
	m_lNETReadPointer = 0;
	m_iNETTotalReadBlockID = 0;
	m_iNETReadBlockID = 0;	


	m_llFSTotalReadPointer = 0;
	m_lFSReadPointer = 0;
	m_iFSTotalReadBlockID = 0;
	m_iFSReadBlockID = 0;	

	m_llTotalWritePointer = 0;
	m_lWritePointer = 0;
	m_iTotalWriteBlockID = 0;
	m_iWriteBlockID = 0;


	m_llRAIDTotalWritePointer = 0;
	m_lRAIDWritePointer = 0;
	m_iRAIDTotalWriteBlockID = 0;
	m_iRAIDWriteBlockID = 0;	

	m_llTotalReadPointer = 0;
	m_lReadPointer = 0;
	m_iTotalReadBlockID = 0;
	m_iReadBlockID = 0;
}

BYTE CLoopBuffer::LB_LoopBufferDataRead(BYTE* pBuf,int iLen,int iReadBlockID,int iTotalReadBlockID)
{
	if((m_llRAIDTotalWritePointer - m_llTotalReadPointer) > m_iTotalSize)
	{
		return 1;			
	}

	memcpy(pBuf, m_pRawDataBuffer+m_lReadPointer, iLen);
	m_lReadPointer += iLen;
	if(m_lReadPointer==m_iBlockSize*m_iBlockCount)
	{
		m_lReadPointer=0;
	}
	m_llTotalReadPointer=m_llTotalReadPointer+iLen;
	m_iReadBlockID = iReadBlockID;
	m_iTotalReadBlockID = iTotalReadBlockID;
	return 0;
}