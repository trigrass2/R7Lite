1. su root

2. cp driversetup folder into computer

3. open driversetip folder with console

4. execute: "./driver_setup"

5. reboot